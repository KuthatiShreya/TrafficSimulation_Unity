using UnityEngine;

public class WheelRotation : MonoBehaviour
{
    public float rotationSpeed = 360f;  // Degrees per second

    void Update()
    {
        // Rotate wheel around its local X-axis
        transform.Rotate(Vector3.right * rotationSpeed * Time.deltaTime);
    }
}
