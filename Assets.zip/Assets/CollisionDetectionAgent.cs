using UnityEngine;
using TMPro;

public class CollisionAvoidance : MonoBehaviour
{
    public float speed = 5f;
    public float rotationSpeed = 200f;
    public Transform targetPosition;
    public Transform spawnPoint;
    public TextMeshProUGUI collisionAlertText;

    private Rigidbody vehicleRigidbody;
    private bool isColliding = false;

    void Start()
    {
        vehicleRigidbody = GetComponent<Rigidbody>();
        ResetEnvironment();
    }

    void Update()
    {
        // Move forward/backward
        float moveAction = Input.GetAxis("Vertical");
        vehicleRigidbody.velocity = transform.forward * moveAction * speed;

        // Rotate left/right
        float turnAction = Input.GetAxis("Horizontal");
        transform.Rotate(Vector3.up * turnAction * rotationSpeed * Time.deltaTime);

        // Check if target reached
        if (Vector3.Distance(transform.position, targetPosition.position) < 1.5f)
        {
            collisionAlertText.text = "Target Reached!";
            ResetEnvironment();
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        isColliding = true;
        collisionAlertText.text = "Collision Detected!";
        ResetEnvironment();
    }

    private void ResetEnvironment()
    {
        // Reset position and stop movement
        transform.position = spawnPoint.position;
        vehicleRigidbody.velocity = Vector3.zero;

        // Reset collision state
        isColliding = false;
        collisionAlertText.text = "";
    }
}
