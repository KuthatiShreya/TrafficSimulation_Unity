using UnityEngine;

public class VehicleMovement : MonoBehaviour
{
    public Transform[] waypoints; // Array of waypoints
    public float speed = 5f; // Speed of the vehicle
    public TrafficLightController trafficLightController; // Reference to the Traffic Light Controller
    public float stopDistance = 5f; // Distance to stop at the red light

    private int currentWaypointIndex = 0;
    private bool isWaitingAtRedLight = false; // Flag to check if the vehicle is stopped at a red light
    private Rigidbody rb; // Reference to Rigidbody

    void Start()
    {
        rb = GetComponent<Rigidbody>();

        if (waypoints.Length == 0)
        {
            Debug.LogError("No waypoints assigned to the vehicle. Please assign waypoints in the Inspector.");
        }
    }

    void FixedUpdate()
    {
        // Ensure waypoints are assigned
        if (waypoints.Length == 0) return;

        // Handle traffic light behavior
        HandleTrafficLight();

        // If waiting at a red light, don't proceed
        if (isWaitingAtRedLight) return;

        // Move the vehicle towards the next waypoint
        MoveTowardsWaypoint();

        // Check if the vehicle has reached the current waypoint
        CheckWaypointReached();
    }

    void HandleTrafficLight()
    {
        if (trafficLightController.CurrentLightIndex == 0) // 0 = red light
        {
            // Stop vehicle near the traffic light
            if (Vector3.Distance(transform.position, waypoints[currentWaypointIndex].position) < stopDistance)
            {
                isWaitingAtRedLight = true;
                rb.velocity = Vector3.zero; // Stop immediately
                Debug.Log("Vehicle stopped at red light.");
            }
        }
        else if (trafficLightController.CurrentLightIndex == 2) // 2 = green light
        {
            // Allow vehicle to move
            isWaitingAtRedLight = false;
        }
    }

    void MoveTowardsWaypoint()
    {
        // Get the target waypoint
        Transform targetWaypoint = waypoints[currentWaypointIndex];

        // Calculate direction
        Vector3 direction = (targetWaypoint.position - transform.position).normalized;

        // Move the vehicle using Rigidbody
        rb.MovePosition(transform.position + direction * speed * Time.deltaTime);

        // Smoothly rotate the vehicle to face the direction of movement
        Quaternion targetRotation = Quaternion.LookRotation(direction);
        transform.rotation = Quaternion.Slerp(transform.rotation, targetRotation, Time.deltaTime * 5f);
    }

    void CheckWaypointReached()
    {
        // Get the current waypoint
        Transform targetWaypoint = waypoints[currentWaypointIndex];

        // Check if the vehicle is close to the waypoint
        if (Vector3.Distance(transform.position, targetWaypoint.position) < 1f)
        {
            currentWaypointIndex++;

            // Randomize turns if needed (e.g., for intersections)
            if (Random.value > 0.5f && currentWaypointIndex < waypoints.Length - 1)
            {
                currentWaypointIndex = Random.Range(0, waypoints.Length); // Pick a random waypoint for turning
            }

            // Stop the vehicle when reaching the last waypoint
            if (currentWaypointIndex >= waypoints.Length)
            {
                Debug.LogWarning("Vehicle reached the last waypoint. Stopping.");
                speed = 0f;
                rb.velocity = Vector3.zero; // Stop rigidbody movement
                return;
            }
        }
    }

    void OnCollisionEnter(Collision collision)
    {
        // Handle collision without allowing rotation
        Debug.Log("Collision detected with: " + collision.gameObject.name);

        // Prevent unwanted rotations by freezing the Rigidbody's rotation
        rb.constraints = RigidbodyConstraints.FreezeRotation;
    }

    void OnCollisionExit(Collision collision)
    {
        // Restore movement after collision
        rb.constraints = RigidbodyConstraints.None;
        rb.constraints = RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationZ;
    }
}
