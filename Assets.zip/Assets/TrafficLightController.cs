using UnityEngine;

public class TrafficLightController : MonoBehaviour
{
    public Material redLight;
    public Material yellowLight;
    public Material greenLight;

    private Renderer trafficLightRenderer; // Single Renderer

    public float redLightDuration = 10f;
    public float yellowLightDuration = 2f;
    public float greenLightDuration = 5f;

    private float timer = 0f;
    public int CurrentLightIndex = 0; // 0 = Red, 1 = Yellow, 2 = Green

    void Start()
    {
        trafficLightRenderer = GetComponent<Renderer>(); // Get the renderer component
        SetRedLight(); // Start with red light
    }

    void Update()
    {
        timer += Time.deltaTime;

        if (CurrentLightIndex == 0 && timer >= redLightDuration)
        {
            SetGreenLight();
        }
        else if (CurrentLightIndex == 2 && timer >= greenLightDuration)
        {
            SetYellowLight();
        }
        else if (CurrentLightIndex == 1 && timer >= yellowLightDuration)
        {
            SetRedLight();
        }
    }

    void SetRedLight()
    {
        CurrentLightIndex = 0;
        timer = 0f;
        trafficLightRenderer.material = redLight; // Set the red light material
    }

    void SetYellowLight()
    {
        CurrentLightIndex = 1;
        timer = 0f;
        trafficLightRenderer.material = yellowLight; // Set the yellow light material
    }

    void SetGreenLight()
    {
        CurrentLightIndex = 2;
        timer = 0f;
        trafficLightRenderer.material = greenLight; // Set the green light material
    }
}
