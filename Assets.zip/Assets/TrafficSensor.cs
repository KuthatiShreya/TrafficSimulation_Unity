using UnityEngine;

public class TrafficSensor : MonoBehaviour
{
    public float detectionRadius = 5f; // Radius to detect vehicles
    public int vehicleCount = 0; // Count of vehicles detected

    void Update()
    {
        // Clear the vehicle count each frame
        vehicleCount = 0;

        // Check for vehicles within the detection radius
        Collider[] hitColliders = Physics.OverlapSphere(transform.position, detectionRadius);
        foreach (var hitCollider in hitColliders)
        {
            if (hitCollider.CompareTag("Vehicle"))
            {
                vehicleCount++;
            }
        }
    }
}
